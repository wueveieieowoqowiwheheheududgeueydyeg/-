
let handler = async (m, { conn }) => {

m.reply(`
≡  *DyLuxᴮᴼᵀ ┃ SUPPORT*

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Grupo *1*
https://chat.whatsapp.com/IO9jmpI72ejHiN4unRZleU

▢ Grupo *2*
https://chat.whatsapp.com/CDUqNRu5Kh5KY5uqQI0BKE

▢ Grupo *NSFW* 🔞
https://chat.whatsapp.com/F0JTTyZ3hsoL7OlU8TEpuH

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Todos los Grupos
 https://instabio.cc/fg98ff

▢ *Telegram*
• https://t.me/fgawgp

 ▢ *PayPal*
• https://paypal.me/fg98f

▢ *YouTube*
• https://www.youtube.com/fg98f`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groupdylux', 'dxgp', 'dygp', 'gpdylux', 'support'] 

export default handler
